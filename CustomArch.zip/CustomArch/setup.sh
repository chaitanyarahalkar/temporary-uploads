#!/bin/bash

#colors
R='\033[1;31m'
B='\033[1;34m'
C='\033[0;36m'
G='\033[1;32m'
W='\033[1;37m'
Y='\033[1;33m'

DIR="$(pwd)"
PR1="aurafetch"
PR2="perl-linux-desktopfiles"
PR3="yay"
PR4="plymouth"


## Setting Things Up
echo
echo -e $Y" [*] Installing Dependencies - "$C
echo
sudo pacman -Sy git archiso --noconfirm
echo
echo -e $G" [*] Succesfully Installed."$C
echo
echo -e $Y" [*] Modifying /usr/bin/mkarchiso - "$C
sudo cp /usr/bin/mkarchiso{,.bak} && sudo sed -i -e 's/-c -G -M/-i -c -G -M/g' /usr/bin/mkarchiso
echo
echo -e $G" [*] Succesfully Modified."$C
echo

## Cloning AUR Packages
cd $DIR/pkgs

echo -e $Y" [*] Downloading AUR Packages - "$C
echo
echo -e $Y" [*] Cloning aurafetch-git - "$C
git clone https://aur.archlinux.org/aurafetch-git.git --depth 1 $PR1
echo
echo -e $Y" [*] Cloning perl-linux-desktopfiles - "$C
git clone https://aur.archlinux.org/perl-linux-desktopfiles.git --depth 1 $PR2
echo
echo -e $Y"[*] Cloning plymouth - "$C
git clone https://aur.archlinux.org/plymouth.git --depth 1 $PR3
echo
echo -e $Y" [*] Cloning yay - "$C
git clone https://aur.archlinux.org/yay.git --depth 1 $PR4
echo
echo -e $G" [*] Downloaded Successfully."$C
echo

## Building AUR Packages
mkdir -p ../localrepo/i686 ../localrepo/x86_64

echo -e $Y" [*] Building AUR Packages - "$C
echo
echo -e $Y" [*] Building $PR1 - "$C
cd $PR1 && makepkg -s
mv *.pkg.tar.xz ../../localrepo/x86_64
cd ..

echo -e $Y" [*] Building $PR2 - "$C
cd $PR2 && makepkg -s
mv *.pkg.tar.xz ../../localrepo/x86_64
cd ..

echo -e $Y" [*] Building $PR3 - "$C
cd $PR3 && makepkg -s
mv *.pkg.tar.xz ../../localrepo/x86_64
cd ..

echo -e $Y"[*] Building $PR4 - "$C
cd $PR4
cp -r $DIR/pkgs/beat $DIR/pkgs/plymouth
sed -i '$d' PKGBUILD
cat >> PKGBUILD <<EOL
  sed -i -e 's/Theme=.*/Theme=beat/g' \$pkgdir/etc/plymouth/plymouthd.conf
  sed -i -e 's/ShowDelay=.*/ShowDelay=1/g' \$pkgdir/etc/plymouth/plymouthd.conf
  cp -r ../../beat \$pkgdir/usr/share/plymouth/themes
}
EOL
sum1=$(md5sum sddm-plymouth.service |  awk -F ' ' '{print $1}')
cat > sddm-plymouth.service <<EOL
[Unit]
Description=Simple Desktop Display Manager
Documentation=man:sddm(1) man:sddm.conf(5)
Conflicts=getty@tty1.service
Wants=plymouth-deactivate.service
After=systemd-user-sessions.service getty@tty1.service plymouth-deactivate.service plymouth-quit.service systemd-logind.service

[Service]
ExecStart=/usr/bin/sddm
Restart=always

[Install]
Alias=display-manager.service
EOL
sum2=$(md5sum sddm-plymouth.service |  awk -F ' ' '{print $1}')
sed -i -e "s/$sum1/$sum2/g" PKGBUILD
makepkg -s
mv *.pkg.tar.xz ../../localrepo/x86_64
cd ..

echo
echo -e $G" [*] All Packages Built Successfully."$C
echo

## Setting up LocalRepo
cd $DIR/localrepo/x86_64
echo -e $Y" [*] Setting Up Local Repository - "$C
echo
repo-add localrepo.db.tar.gz *
echo
echo -e $Y" [*] Appending Repo Config in Pacman file - "$C
echo
echo "[localrepo]" >> $DIR/customiso/pacman.conf
echo "SigLevel = Optional TrustAll" >> $DIR/customiso/pacman.conf
echo "Server = file://$DIR/localrepo/\$arch" >> $DIR/customiso/pacman.conf
echo


echo
echo -e $Y" [*] Making owner ROOT to avoid problems with false permissions."$C
sudo chown -R root:root $DIR/customiso/
echo

echo -e $Y" [*] Cleaning Up... "$C
cd $DIR/pkgs
rm -rf $PR1 $PR2 $PR3 $PR4
echo
echo -e $R" [*] Setup Completed."
echo
exit
