#!/bin/bash

pacman-key --init
pacman-key --populate

# Attempt to work around build failure on debian hosts.
mkdir -p /build/archiso/work/x86_64/airootfs/run/shm
mkdir -p /build/archiso/work/x86_64/airootfs/var/run/shm
mkdir -p /run/shm
mkdir -p /var/run/shm

set -e -u

sed -i 's/#\(en_US\.UTF-8\)/\1/' /etc/locale.gen
locale-gen

ln -sf /usr/share/zoneinfo/UTC /etc/localtime

usermod -s /usr/bin/fish root
#cp -aT /etc/skel/ /root/

## Liveuser
useradd -m -p $(openssl passwd frost) -g users -G "adm,audio,floppy,log,network,rfkill,scanner,storage,optical,power,wheel" -s /bin/fish frost
chown -R frost:users /home/frost
echo "frost ALL=(ALL) NOPASSWD: ALL" >> /etc/sudoers;


sed -i 's/#\(PermitRootLogin \).\+/\1yes/' /etc/ssh/sshd_config
sed -i "s/#Server/Server/g" /etc/pacman.d/mirrorlist
sed -i 's/#\(Storage=\)auto/\1volatile/' /etc/systemd/journald.conf

sed -i 's/#\(HandleSuspendKey=\)suspend/\1ignore/' /etc/systemd/logind.conf
sed -i 's/#\(HandleHibernateKey=\)hibernate/\1ignore/' /etc/systemd/logind.conf
sed -i 's/#\(HandleLidSwitch=\)suspend/\1ignore/' /etc/systemd/logind.conf


# Branding
sed -i.bak 's/Arch Linux/Frost OS/g' /usr/lib/os-release
sed -i.bak 's/arch/frost/g' /usr/lib/os-release
sed -i.bak 's#www.archlinux.org#github.com/chaitanyarahalkar/frostOS#g' /usr/lib/os-release
sed -i.bak 's#bbs.archlinux.org#github.com/chaitanyarahalkar/frostOS#g' /usr/lib/os-release
sed -i.bak 's#bugs.archlinux.org#github.com/chaitanyarahalkar/frostOS#g' /usr/lib/os-release

# Update locate database
updatedb 

systemctl enable pacman-init.service choose-mirror.service
systemctl enable sddm.service
systemctl set-default graphical.target

## Services
systemctl enable NetworkManager.service 
systemctl enable wpa_supplicant.service
systemctl enable sddm-plymouth.service

# Enable the DHCP Daemon
systemctl enable dhcpd4.service

# Enable NTP Daemon
systemctl enable ntpd.service

# Enable Cron
systemctl enable cronie.service

## Mods
sed -i -e 's/MODULES=()/MODULES=(i915)/g' /etc/mkinitcpio.conf
sed -i -e 's/HOOKS=(base udev autodetect modconf block filesystems keyboard fsck)/HOOKS=(base udev plymouth plymouth-encrypt block filesystems keyboard)/g' /etc/mkinitcpio.conf

## Remove localrepo lines
sed -i '$d' /etc/pacman.conf && sed -i '$d' /etc/pacman.conf && sed -i '$d' /etc/pacman.conf

systemctl set-default graphical.target
